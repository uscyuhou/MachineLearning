% Label of the training data
Label=[1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0, 0,0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]';

% Initial the weight
W_ij=100*(2*rand(961,100)-1); % Input-Hidden weight,the last line is the bias weight %%
W_jk=0.1*(2*rand(101,1)-1);       % Hidden-Output weight. The last line is also the bias %%

n=1;
while n<=600

a=1;
while a<=184
% for each data, forward propagation
%input the image
imageName=strcat(num2str(a),'.pgm');
Image=imread(imageName);
Image=double(Image);  % convert from uint8 to double type for calculation
Image=Image./255;     % scale pixel to range from 0 to 1
Image=Image';
Data_In=Image(:)';  %form the input data. This is 1*960 without bias 

%
[COEFF,SCORE,Latent,tsquare]=princomp(Data_In');
Data_In=SCORE';
Data_In_Bias=[Data_In,1];    %Add the Bias

%calculate the output of hidden layer
%x is the input of each hidden unit. each one of the 100 number represents each input of unit in hidden level
x=Data_In_Bias*W_ij;  %% 
H=1./(1+exp(-x));  %H is the output of each one of 100 units in the hidden layer(sigmoid function)
H_Bias=[H,1];  %Add the bias to the H;

%calculate the output of the output layer
O1=H_Bias*W_jk;  %this is the output of the final layer.  %%
O=1./(1+exp(-O1));




% for this data's back propogation.

% weight gradient
% weight without bias gradient
  %weight between hidden and output 
e=Label(a,1)-O;
Gradient_HO=-e.*H;  %this is the gradient of each one of 100 w between H and O
  %weight between hidden and input
Gradient_IH=zeros(960,100);
for i=1:960
    for j=1:100
       Gradient_IH(i,j)=H(j)*(1-H(j))*Data_In(i)*W_jk(j)*e;
    end
end
% bias gradient
  %bias between hidden and output 
Bias_Gradient_HO=-e;
Bias_Gradient_IH=zeros(1,100);
for k=1:100
    Bias_Gradient_IH(k)=H(k)*(1-H(k))*W_jk(k)*e;
end

% update all weight
s=0.1;
% weight between H-O 
W_jk(1:100,1)=W_jk(1:100,1)-s.*Gradient_HO';
% % Bias between H-0
W_jk(101,1)=W_jk(101,1)-s*Bias_Gradient_HO;
% weight between I-H 
W_ij(1:960,:)=W_ij(1:960,:)-s.*Gradient_IH;
% % Bias between I-H
W_ij(961,:)=W_ij(961,:)+s.*Bias_Gradient_IH;

a=a+1;
end

n=n+1;
end

