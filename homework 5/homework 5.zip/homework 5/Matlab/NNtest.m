W_ij=W_ij;
W_jk=W_jk;
O=zeros(1,83);
t=1;
while t<=83 
% for each data, forward propagation
%input the image
imageName=strcat(num2str(t),'.pgm');
Image=imread(imageName);
Image=double(Image);  % convert from uint8 to double type for calculation
Image=Image./255;     % scale pixel to range from 0 to 1
Image=Image';
Data_In=Image(:)';  %form the input data. This is 1*960 without bias 
Data_In_Bias=[Data_In,1];    %Add the Bias

%
[COEFF,SCORE,Latent,tsquare]=princomp(Data_In_Bias');
Data_In_Bias=SCORE';

%calculate the output of hidden layer
%x is the input of each hidden unit. each one of the 100 number represents each input of unit in hidden level
x=Data_In_Bias*W_ij;   %%  
H=1./(1+exp(-x));  %H is the output of each one of 100 units in the hidden layer(sigmoid function)
H_Bias=[H,1];  %Add the bias to the H;

%calculate the output of the output layer
O(1,t)=H_Bias*W_jk;  %this is the output of the final layer.

t=t+1;
end