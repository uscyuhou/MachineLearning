#INF552
#Spring2017
#Assignment5-ANN
#Group Member: Yu Hou; Haoteng Tang.



from math import sqrt
from math import exp
import random
import math
import sys
import numpy as np
from numpy.linalg import eig
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

from matplotlib import cm

def loadPgm(imageName):
    f = open(imageName, 'rb')
    f.readline()    # skip the first line
    f.readline()    # skip the second line

    row, colum= f.readline().strip().split()
    row = int(row)
    colum = int(colum)

    scale = int(f.readline().strip())

    image = []
    for index in range(row*colum):
        image.append(ord(f.read(1))/float(scale))
    return image

def readData(fileName):
    xDataList = []
    yDataList = []
    zDataList = []

    f = open(fileName, 'r')

    for image in f.readlines():
        image = image.strip()
        xDataList.append(loadPgm(image))
        zDataList.append(image)
        if 'down' in image:
            yDataList.append(1)
        else:
            yDataList.append(0)
    return xDataList, yDataList,zDataList

def computor(x):

    return x*(1-x)


def sitaS(x):

    # for index in range(len(x)):
    #     for j in range(len(x[index])):
    #         if -x[index][j] > math.log(sys.float_info.max):
    #             x[index][j] = 0

    return 1/(1+np.exp(-x))






def aNN(x,y):

    y = np.array([y]).T
    yeta = 0.1

    epoch = 1000
    w1 = np.random.uniform(-1.0, 1.0, size=(960, 100))
    w2 = np.random.uniform(-1.0, 1.0, size=(100, 1))

    for k in range (epoch):

        for i in range(len(x)):

            # forward
            layer0 = np.array([x[i]])
            layer1 = sitaS(np.dot(layer0,w1))
            layer1 = np.array(layer1)
            layer2 = sitaS(np.dot(layer1,w2))
            layer2 = np.array(layer2)



            # backword
            delta2 = (layer2-y[i])*layer2*(1 - layer2)

            # print((yeta * np.matrix(layer1.T) * np.matrix(delta2)))
            w2 = w2 - (yeta * np.matrix(layer1.T) * np.matrix(delta2))

            hidden=list(np.array( (np.matrix(delta2)*np.matrix(w2).getT()) ))
            hiddenX=0.0
            for i in range(len(hidden[0])):
                hiddenX = hiddenX +hidden[0][i]

            delta1 = layer1*(1-layer1)*np.array( (np.matrix(delta2)*np.matrix(w2).getT()) )
            w1 = w1 - (  yeta   *   np.matrix(layer0.T)*np.matrix(delta1))

        # accurancy
        layer0 = np.array(x)

        layer1 = sitaS(np.dot(layer0, w1))
        layer1 = np.array(layer1)

        layer2 = sitaS(np.dot(layer1, w2))
        layer2 = np.array(layer2)
        error = (y-layer2)**2
        count=0

        for i in range(len(error)):
            if error[i] < 0.25:
                count=count+1
        accurancy = count/len(error)
        if (k%50 == 0):
            print("epoch number: ",k)
            print("Accuracy for training data:",accurancy)

    return w1,w2

def predict(w1,w2,x,y,z):
    y = np.array([y]).T

    layer0 = np.array(x)

    layer1 = sitaS(np.dot(layer0, w1))
    layer1 = np.array(layer1)

    layer2 = sitaS(np.dot(layer1, w2))
    layer2 = np.array(layer2)

    predict = layer2

    TP = 0
    TN = 0
    FP = 0
    FN = 0


    for i in range(len(layer2)):
        if layer2[i] >= 0.5 and y[i]==1:
            TP = TP + 1
            predict[i]=1
        if layer2[i] < 0.5 and y[i]==0:
            TN = TN + 1
            predict[i] = 0
        if layer2[i] >= 0.5 and y[i]==0:
            FP = FP + 1
            predict[i] = 1
        if layer2[i] < 0.5 and y[i]==1:
            FN = FN + 1
            predict[i] = 0
    truePositive=TP/(TP+FN)
    trueNegative=TN/(TN+FP)
    positivePre = TP/(TP+FP)
    negativePre = TN/(TN+FN)
    accuracy = (TP+TN) / (TP+TN+FP+FN)

    count = 0
    for i in range(len(layer2)):
        print("PREDICT of",z[i],"iS: ",predict[i],"Real is: ", y[i])
        if layer2[i] > 0.5:
            count = count + 1

    creal=0

    for index in range(len(y)):
        if y[index] == 1:
            creal = creal + 1


    print("The predictive number of '1': ",count)
    print("The real number in testing data of '1': ",creal)
    print("The true positive rate:",truePositive)
    print("The true negative rate:",trueNegative)
    print("The positive predictive value:", positivePre)
    print("The negative predictive value:", negativePre)
    print("The total accuracy:",accuracy)


if __name__ == '__main__':
    xTraining,yTraining,zTraining = readData('downgesture_train.list')

    w1,w2 = aNN(xTraining,yTraining)
    xTest,yTest,zTest = readData('downgesture_test.list')
    predict(w1,w2,xTest,yTest,zTest)

