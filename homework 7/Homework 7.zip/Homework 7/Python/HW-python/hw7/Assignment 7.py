#INF552
#Spring2017
#Assignment7-Support Vector Machines
#Group Member: Yu Hou; Haoteng Tang.


from math import sqrt
from math import exp
import numpy as np
import matplotlib.pyplot as plt
import cvxopt
import cvxopt.solvers

from matplotlib import cm

def getDataFromFile(filename):
    xDataList = []
    yDataList = []
    f = open(filename, 'r')
    newLine = f.readline()          # get the first line

    while newLine:
        string = newLine[:-1]  # trim the " number"

        newRecord = string.split(",")  #split as ","
        x = [0.0,0.0]
        x[0] = float(newRecord[0])          #change the formation of the data.
        x[1] = float(newRecord[1])



        xDataList.append(x)      #add a new record
        yDataList.append(float(newRecord[2]))           #the 4th column
        newLine = f.readline()          #next line

    return xDataList,yDataList

def drawOrigList(xDataList,yDataList):

    plt.title('Data plotted in 2D')
    for index in range(len(xDataList)):
        if yDataList[index] == -1.0:
            plt.scatter(xDataList[index][0], xDataList[index][1], marker='*', color='r')
        if yDataList[index] == 1.0:
            plt.scatter(xDataList[index][0], xDataList[index][1], marker = '+',color ='b')

    plt.show()

def  draw(w,b,support):
    print("The Equation of the line of separation is ",w[0,0],"*x + ",w[0,1],"*y ",float(b[0][0]), " = 0")

    x = np.linspace(-0.2, 1.2)
    y = np.linspace(-0.2, 1.2)
    y1 = np.linspace(-0.2, 1.2)
    y2 = np.linspace(-0.2, 1.2)

    slope = -w[0,0]/w[0,1]
    b1 = xDataList[support[0]][1]-slope*xDataList[support[0]][0]
    b2 = xDataList[support[2]][1]-slope*xDataList[support[2]][0]

    # b2 = np.dot(xDataList[support[2]], np.transpose(w))

    for index in range(len(x)):
        y[index] = slope * x[index] - (b)/w[0,1]     # draw the middle line
    for index in range(len(x)):
        y1[index] = slope * x[index] + (b1)      # draw the middle line
    for index in range(len(x)):
        y2[index] = slope * x[index] + (b2)  # draw the middle line


    plt.plot(x, y, '-')
    plt.plot(x, y1, '--')
    plt.plot(x, y2, '--')

    plt.title('SVM result')
    for index in range(len(xDataList)):
        for i in range(len(support)):
            if index==support[i]:
                plt.scatter(xDataList[index][0], xDataList[index][1], marker='^', color='g')
                break
            else:
                if yDataList[index] == -1.0:
                    plt.scatter(xDataList[index][0], xDataList[index][1], marker='*', color='r')
                if yDataList[index] == 1.0:
                    plt.scatter(xDataList[index][0], xDataList[index][1], marker='+', color='b')



    plt.show()




def SVMforLinear(xDataList, yDataList):
    xDataList=np.matrix(xDataList)
    numberOfRecord,dimension = xDataList.shape
    Q= np.zeros((numberOfRecord,numberOfRecord))
    for i in range(numberOfRecord):
        for j in range(numberOfRecord):
            Q[i,j]=yDataList[i]*yDataList[j]*np.dot(xDataList[i],np.transpose(xDataList[j]))

    P=cvxopt.matrix(Q)      # cvxopt coefficient P
    q= cvxopt.matrix(np.ones(numberOfRecord)*-1)        # cvxopt coefficient q
    # print(q)
    G = cvxopt.matrix(np.diag(np.ones(numberOfRecord) * -1))    # cvxopt coefficient G
    h = cvxopt.matrix(np.zeros(numberOfRecord))
    # print(h)
    A= cvxopt.matrix(yDataList,(1,numberOfRecord))      # cvxopt coefficient A
    # print(A)
    b= cvxopt.matrix(0.0)                               # cvxopt coefficient b
    # print(b)
    # print(np.diag(np.ones(numberOfRecord)*-1))
    result=cvxopt.solvers.qp(P,q,G,h,A,b)
    arfa=[]
    arfa=result["x"]
    # print(np.transpose(np.array(arfa))*np.array(yDataList))
    w=np.dot(np.transpose(np.array(arfa))*np.array(yDataList),xDataList)
    # print(w)
    b=0.0


    supportVectorNumber=[]
    for index in range(len(arfa)):
        if arfa[index]> 1e-0 :
            supportVectorNumber.append(index)
            b= 1.0/yDataList[index] - np.dot(xDataList[index],np.transpose(w))

    draw(w,b,supportVectorNumber)



if __name__ == '__main__':
    xDataList, yDataList = getDataFromFile("linsep.txt")


    # drawOrigList(xDataList,yDataList)                             ## draw all data point into the 3D
    SVMforLinear(xDataList, yDataList)