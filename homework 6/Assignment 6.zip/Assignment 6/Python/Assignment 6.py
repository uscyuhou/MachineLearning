#INF552
#Spring2017
#Assignment6-HMM&Viterbi
#Group Member: Yu Hou; Haoteng Tang.


import math
import numpy as np
import sys


def readData(fileName):
    location =[]

    f = open(fileName, 'r')
    f.readline()
    f.readline()        #skip first two lines

    for index in range(10):
        numbers=f.readline()
        data=[]
        numbers = numbers.strip().split()
        for number in numbers:
            data.append(int(number))
        location.append(data)

    for index in range(12):
        numbers=f.readline()        #skip 12 lines

    observe = []
    for index in range(11):
        numbers=f.readline()
        data=[]
        numbers = numbers.strip().split()
        for number in numbers:
            data.append(float(number))
        observe.append(data)
    tower=[(0,0),(0,9),(9,0),(9,9)]
    # print(location)
    # print(observe)
    # print(tower)
    return location,observe,tower

# calculate the transition probability
def transitionProb(point,location):
    trans={}
    x=point[0]
    y=point[1]

    if y-1>=0 and location[x][y-1]==1:
        newPoint = (x,y-1)
        trans.update({newPoint:0.0})
    if x-1>=0 and location[x-1][y]==1:
        newPoint = (x-1,y)
        trans.update({newPoint:0.0})
    if y+1<10 and location[x][y+1]==1:
        newPoint = (x,y+1)
        trans.update({newPoint:0.0})
    if x+1<10 and location[x+1][y]==1:
        newPoint = (x+1,y)
        trans.update({newPoint:0.0})

    count=len(trans)

    p=1/count
    for data in trans:
        trans[data]=p
    # print(trans)

    return trans

def distance(point1,point2):
    x1 = point1[0]
    y1 = point1[1]
    x2 = point2[0]
    y2 = point2[1]

    d= math.sqrt( ((x1-x2)**2) + ((y1-y2)**2) )

    return d

def emission(states,observe,tower,location):
    em_pro = {}
    for i in range(len(states)):
        em_pro.update({states[i]:{}})
        for j in range(len(observe)):
            ptotal=1.0

            if location[states[i][0]][states[i][1]]==1:             #if it is a not wall

                for k in range(len(tower)):
                    realDistance=distance(states[i],tower[k])

                    if realDistance*0.7<=observe[j][k] and observe[j][k]<=realDistance*1.3:
                        p = 1.0/((round(realDistance*1.3,1)-round(realDistance*0.7,1))*10)
                    else:
                        p=0.0

                    ptotal = ptotal * p

            else:
                ptotal=0.0

            em_pro.get(states[i]).update({j:ptotal})
    # print(em_pro)
    return  em_pro

#
def update(probElement,emissPro,number):

    newprob = probElement.copy()        # record new prob after trans
    newmap = probElement.copy()         # record new track information after trans
    newtrans = probElement.copy()       # record the who contribute more give the information to newmap

    for vector in newprob:
        newprob[vector]=[]
    for vector in newmap:
        newmap[vector]=[]
    for vector in newtrans:
        newtrans[vector]=[]

    for vector in probElement:
        trans=transitionProb(vector,location)
        for element in trans:

            p = (probElement.get(vector)) * (trans.get(element)) * (emissPro.get(element).get(number))
                                        #p = current(last) * trans * (observe|trans)
            newprob.get(element).append(p)
            newtrans.get(element).append((probElement.get(vector)) * (trans.get(element)))
            newmap.get(element).append(vector)
    # print(newmap)
    # print(newprob)
    # print(newtrans)
    for vector in newtrans:
        bestprob = 0.0
        bestloc = 0
        for i in range(len(newtrans.get(vector))):
            if newtrans.get(vector)[i] > bestprob:
                bestprob=newtrans.get(vector)[i]
                bestloc = i
        newtrans[vector]=bestprob
        list1=newmap.get(vector)

        if list1 != []:
            newmap[vector]=list1[bestloc]
            if bestprob==0.0:
                newmap[vector]=None

    for vector in newtrans:
        bestprob = 0.0
        bestloc = 0
        for i in range(len(newprob.get(vector))):
            if newprob.get(vector)[i] > bestprob:
                bestprob = newprob.get(vector)[i]
                bestloc = i
        newprob[vector] = bestprob



    return newmap,newprob

def viterbi(startPro,emissPro):
    prob=[]
    currentPro = startPro.copy()            # start prob all are 1/87

    for vector in currentPro:
        p = currentPro.get(vector)*emissPro.get(vector).get(0)      #p= current*(observe|current)
        currentPro[vector]= p
    prob.append(currentPro)

    currentMap = currentPro.copy()
    for vector in currentMap:
        currentMap[vector]= vector

    map = []
    map.append(currentMap)


    for index in range(1,11):

        mapNew,probNew=update(prob[index-1],emissPro,index)
        map.append(mapNew)
        prob.append(probNew)

    bestprob=0.0
    bestmap=(0,0)
    for vector in prob[10]:
        if prob[10].get(vector)>bestprob:
            bestprob=prob[10].get(vector)
            bestmap=vector
    path = []
    path.append(bestmap)

    for i in range(len(map)-1,0,-1):
        bestmap=map[i].get(bestmap)
        path.append(bestmap)
    pathNew = []
    for i in range(len(path)):
        pathNew.append(path.pop())
    return pathNew

def hmm(location,observe,tower):
    states =[]
    start_probability = {}
    for i in range(10):
        for j in range(10):
            point = (i,j)
            if location[i][j]==1:
                states.append(point)
                start_probability.update({point:1/87})
    # print(start_probability)
    emission_probability= emission(states,observe,tower,location)
    path = viterbi(start_probability,emission_probability)
    print(path)
    for index in range(len(path)):
        location[path[index][0]][path[index][1]]="★"
    print(np.matrix(location))
if __name__ == '__main__':
    location,observe,tower = readData('hmm-data.txt')
    hmm(location,observe,tower)
    transitionProb((0,0),location)

