#INF552
#Spring2017
#Assignment4-Linear Regression
#Group Member: Yu Hou; Haoteng Tang.


from math import sqrt
import random
import numpy as np
from numpy.linalg import eig
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

from matplotlib import cm

#
# This method is used to get 3D point data from film and store them into a list
#
def getDataFromFile(filename):
    xDataList = []
    yDataList = []
    f = open(filename, 'r')
    newLine = f.readline()          # get the first line

    while newLine:
        string = newLine[:-1]  # trim the " number"

        newRecord = string.split(",")  #split as ","
        x = [1.0,0.0,0.0]
        x[1] = float(newRecord[0])          #change the formation of the data.
        x[2] = float(newRecord[1])

        xDataList.append(x)      #add a new record
        yDataList.append(float(newRecord[2]))
        newLine = f.readline()          #next line

    return xDataList,yDataList


def dataTrans(xDataList):
    xDataListNew = []
    for index in range(len(xDataList)):
        x = [1.0, 0.0, 0.0, 0.0, 0.0, 0.0]
        x[0] = xDataList[index][0]
        x[1] = xDataList[index][1]
        x[2] = xDataList[index][2]
        x[3] = xDataList[index][1] ** 2
        x[4] = xDataList[index][2] ** 2
        x[5] = xDataList[index][1] * xDataList[index][2]
        xDataListNew.append(x)

    return xDataListNew

def drawlist(xDataList,z,sita):

    fig = plt.figure(facecolor='w')
    #ax = fig.add_subplot(111, projection='3d')
    ax = fig.gca(projection='3d')

    x = np.delete(np.delete(xDataList, [0], axis=1), [1], axis=1)
    y = np.delete(np.delete(xDataList, [0], axis=1), [0], axis=1)

    X = np.arange(0.0, 1.0, 0.1)
    Y = np.arange(0.0, 1.0, 0.1)
    X, Y = np.meshgrid(X, Y)

    Z=float(sita[0])+X*float(sita[1])+Y*float(sita[2])


    ax.scatter(x, y, z, marker='o', color='blue', s=1)              #x,y and original z values

    ax.plot_surface(X, Y, Z, rstride=1, cstride=1, alpha=0.3)              #x,y and original z values

    # cset = ax.contourf(X, Y, Z, zdir='z', offset=0, color="blue")
    # cset = ax.contourf(X, Y, Z, zdir='x', offset=0, color="blue")
    # cset = ax.contourf(X, Y, Z, zdir='y', offset=0, color="blue")

    ax.set_zlabel('Z')
    ax.set_ylabel('Y')
    ax.set_xlabel('X')
    plt.title("linear regression")
    plt.show()

def linearRegression(xDataList,yDataList):
    z=yDataList                     #original values

    xDataList = np.matrix(xDataList)
    yDataList = np.matrix(yDataList)

    xTDataList = xDataList.getT()
    yTDataList = yDataList.getT()

    sita = (xTDataList*xDataList)**(-1)*xTDataList*yTDataList
    print(sita)
    drawlist(xDataList, z, sita)

def drawlistMulti(xDataList,z,sita):

    fig = plt.figure(facecolor='w')
    #ax = fig.add_subplot(111, projection='3d')
    ax = fig.gca(projection='3d')

    x = np.delete(np.delete(xDataList, [0], axis=1), [1], axis=1)
    y = np.delete(np.delete(xDataList, [0], axis=1), [0], axis=1)

    X = np.arange(0.0, 1.0, 0.1)
    Y = np.arange(0.0, 1.0, 0.1)
    X, Y = np.meshgrid(X, Y)

    Z=float(sita[0])+X*float(sita[1])+Y*float(sita[2])+X**2*float(sita[3])+Y**2*float(sita[4])+X*Y*float(sita[5])


    #ax.scatter(x, y, z, marker='o', color='blue', s=1)              #x,y and original z values

    ax.plot_surface(X, Y, Z, rstride=1, cstride=1, alpha=0.3)              #x,y and original z values

    # cset = ax.contourf(X, Y, Z, zdir='z', offset=0, color="blue")
    # cset = ax.contourf(X, Y, Z, zdir='x', offset=0, color="blue")
    # cset = ax.contourf(X, Y, Z, zdir='y', offset=0, color="blue")


    ax.set_zlabel('Z')
    ax.set_ylabel('Y')
    ax.set_xlabel('X')
    plt.title("linear regression")
    plt.show()

def linearRegressionMulti(xDataList,yDataList):
    z=yDataList                     #original values
    xDataList = np.matrix(xDataList)
    yDataList = np.matrix(yDataList)

    xTDataList = xDataList.getT()
    yTDataList = yDataList.getT()

    sita = (xTDataList*xDataList)**(-1)*xTDataList*yTDataList

    print(sita)
    drawlistMulti(xDataList, z, sita)



if __name__ == '__main__':

    xDataList,yDataList = getDataFromFile("linear-regression.txt")
    linearRegression(xDataList,yDataList)

    # xDataList = dataTrans(xDataList)
    # linearRegressionMulti(xDataList,yDataList)        #transform the data using non-linear regression.
