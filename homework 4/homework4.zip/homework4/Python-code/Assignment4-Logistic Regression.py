#INF552
#Spring2017
#Assignment4-Logistic Regression
#Group Member: Yu Hou; Haoteng Tang.



from math import sqrt
from math import exp
from math import log
import random
import numpy as np
from numpy.linalg import eig
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

from matplotlib import cm

def getDataFromFile(filename):
    xDataList = []
    yDataList = []
    f = open(filename, 'r')
    newLine = f.readline()          # get the first line

    while newLine:
        string = newLine[:-1]  # trim the " number"

        newRecord = string.split(",")  #split as ","
        x = [1.0,0.0,0.0,0.0]
        x[1] = float(newRecord[0])          #change the formation of the data.
        x[2] = float(newRecord[1])
        x[3] = float(newRecord[2])


        xDataList.append(x)      #add a new record
        yDataList.append(float(newRecord[4]))           #the 5th column
        newLine = f.readline()          #next line

    return xDataList,yDataList

def drawClassList(xDataList,yDataList,w):

    fig = plt.figure(facecolor='w')
    ax = fig.gca(projection='3d')

    for index in range(len(yDataList)):
        if yDataList[index]==1:
            ax.scatter(xDataList[index][1], xDataList[index][2], xDataList[index][3], marker='o', color='blue', s=1)  # x,y and original z values
        else:
            ax.scatter(xDataList[index][1], xDataList[index][2], xDataList[index][3], marker='*', color='red', s=1)  # x,y and original z values

    X = np.arange(0.0, 1.0, 0.1)
    Y = np.arange(0.0, 1.0, 0.1)
    X, Y = np.meshgrid(X, Y)


    Z = (-w[0,0]/w[0,3])+((-w[0,1]/w[0,3])*X)+((-w[0,2]/w[0,3])*Y)

    ax.plot_surface(X, Y, Z, rstride=1, cstride=1, alpha=0.6)
    ax.set_zlabel('Z')
    ax.set_ylabel('Y')
    ax.set_xlabel('X')
    plt.title("Logistic Regression")
    plt.show()

def likehoodCalculate(xDataList,yDataList,w):
    n=2000
    likehood = 1.0
    for i in range(len(xDataList)):
        x = np.matrix(xDataList[i])
        eYWX = exp(-yDataList[i] * (w * x.getT()))
        delta = log(1+eYWX)

        likehood=likehood + delta
    likehood=likehood/n
    return likehood

def logisticRegression(xDataList, yDataList, maxIteration):
    yeta = 0.01
    w = [random.random(), random.random(), random.random(), random.random()]
    # w = [0.1, 0.1, 0.1, 0.1]
    w = np.matrix(w)

    n = 2000
    print(xDataList[0])

    for index in range(maxIteration):

        wDelta=np.matrix([0.0,0.0,0.0,0.0])
        for i in range(len(xDataList)):
            x = np.matrix(xDataList[i])
            eYWX = exp( yDataList[i]* ( w * x.getT() ))
            wDelta = wDelta + ( yDataList[i]*(1/(1+eYWX))*x)
        wDelta = (wDelta/n)

        w = w + yeta*wDelta

        print(w)
    return w

if __name__ == '__main__':


    xDataList,yDataList = getDataFromFile("Classification.txt")
    w = logisticRegression(xDataList, yDataList, 7000)
    drawClassList(xDataList,yDataList,w)
