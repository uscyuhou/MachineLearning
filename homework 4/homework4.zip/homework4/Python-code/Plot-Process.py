from math import sqrt
from math import exp
import random
import numpy as np
from numpy.linalg import eig
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

from matplotlib import cm
if __name__ == '__main__':


    yDataList = []
    filename = "Linear Classification -- one result"
    f = open(filename, 'r')
    newLine = f.readline()  # get the first line

    while newLine:
        string = newLine[:]  # trim the " number"
        yDataList.append(int(string))  # the 4th column
        newLine = f.readline()  # next line

    for i in range(len(yDataList)):
        plt.scatter(i, yDataList[i], marker='o', color='r')

    plt.show()
    print(yDataList)