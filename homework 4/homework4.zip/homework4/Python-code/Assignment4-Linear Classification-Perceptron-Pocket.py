#INF552
#Spring2017
#Assignment4-Perceptron-Pocket
#Group Member: Yu Hou; Haoteng Tang.


from math import sqrt
from math import exp
import random
import numpy as np
from numpy.linalg import eig
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

from matplotlib import cm


def getDataFromFile(filename):
    xDataList = []
    yDataList = []
    f = open(filename, 'r')
    newLine = f.readline()          # get the first line

    while newLine:
        string = newLine[:-1]  # trim the " number"

        newRecord = string.split(",")  #split as ","
        x = [1.0,0.0,0.0,0.0]
        x[1] = float(newRecord[0])          #change the formation of the data.
        x[2] = float(newRecord[1])
        x[3] = float(newRecord[2])


        xDataList.append(x)      #add a new record
        yDataList.append(float(newRecord[3]))           #the 4th column
        newLine = f.readline()          #next line

    return xDataList,yDataList

def drawOrigList(xDataList,yDataList):

    fig = plt.figure(facecolor='w')
    ax = fig.gca(projection='3d')

    for index in range(len(yDataList)):
        if yDataList[index]==1:
            ax.scatter(xDataList[index][1], xDataList[index][2], xDataList[index][3], marker='o', color='blue', s=1)  # x,y and original z values
            # p1=plt.scatter( xDataList[index][2], xDataList[index][3], marker='o', color='green', s=1)
            # p2=plt.scatter(xDataList[index][1],  xDataList[index][3], marker='o', color='pink', s=1)
            # p3=plt.scatter(xDataList[index][1], xDataList[index][2],  marker='o', color='black', s=1)

        else:
            ax.scatter(xDataList[index][1], xDataList[index][2], xDataList[index][3], marker='*', color='red', s=1)  # x,y and original z values

    ax.set_zlabel('Z')
    ax.set_ylabel('Y')
    ax.set_xlabel('X')
    plt.title("linear classification")
    plt.show()

def drawClassList(xDataList,yDataList,w):

    fig = plt.figure(facecolor='w')
    ax = fig.gca(projection='3d')

    for index in range(len(yDataList)):
        if yDataList[index]==1:
            ax.scatter(xDataList[index][1], xDataList[index][2], xDataList[index][3], marker='o', color='blue', s=1)  # x,y and original z values
        else:
            ax.scatter(xDataList[index][1], xDataList[index][2], xDataList[index][3], marker='*', color='red', s=1)  # x,y and original z values

    X = np.arange(0.0, 1.0, 0.1)
    Y = np.arange(0.0, 1.0, 0.1)
    X, Y = np.meshgrid(X, Y)


    Z = (-w[0,0]/w[0,3])+((-w[0,1]/w[0,3])*X)+((-w[0,2]/w[0,3])*Y)

    ax.plot_surface(X, Y, Z, rstride=1, cstride=1, alpha=0.6)
    ax.set_zlabel('Z')
    ax.set_ylabel('Y')
    ax.set_xlabel('X')
    plt.title("linear classification")
    plt.show()

def calculate(w,x):
    w = np.matrix(w)
    x = np.matrix(x)
    x = x.getT()
    if w*x >= 0.0:
        return 1.0
    else:
        return -1.0


def linearClassificationPerceptronMethod1(xDataList,yDataList):
    alph = 0.01
    w = [random.random(),random.random(),random.random(),random.random()]
    # w = [0.1, 0.1, 0.1, 0.1]
    w=np.matrix(w)
    print(w)
    n = 2000

    while n > 0:
        count =0
        for index in range(len(xDataList)):

            yOut = calculate(w,xDataList[index])

            yTarget = yDataList[index]

            if yOut != yTarget:
                count=count+1
                #print(np.matrix(10)*(xDataList[index]))
                w = w + np.matrix(alph*(yTarget-yOut)) * xDataList[index]
        n = count
        print(n)

    print(w)
    return w


def linearClassificationPerceptronMethod2(xDataList,yDataList):
    alph = 0.01
    w = [random.random(),random.random(),random.random(),random.random()]
    # w = [0.1,0.1,0.1,0.1]


    w=np.matrix(w)
    print(w)
    n = 2000

    go = True

    while go:
        count =0
        for index in range(len(xDataList)):
            count = count + 1
            yOut = calculate(w,xDataList[index])
            yTarget = yDataList[index]
            if yOut != yTarget:

                w = w + np.matrix(alph*(yTarget-yOut)) * xDataList[index]
                break

        print(count)
        if  count == 2000 :
            go = False

    print(w)
    return w
#...............................................................................................................#
# boundary. Above is Perceptron learning algorithm. below is pocket algorithm.
#...............................................................................................................#


def getDataFromFile2(filename):
    xDataList = []
    yDataList = []
    f = open(filename, 'r')
    newLine = f.readline()          # get the first line

    while newLine:
        string = newLine[:-1]  # trim the " number"

        newRecord = string.split(",")  #split as ","
        x = [1.0,0.0,0.0,0.0]
        x[1] = float(newRecord[0])          #change the formation of the data.
        x[2] = float(newRecord[1])
        x[3] = float(newRecord[2])


        xDataList.append(x)      #add a new record
        yDataList.append(float(newRecord[4]))           #the 5th column
        newLine = f.readline()          #next line

    return xDataList,yDataList

def linearClassificationPocket1(xDataList,yDataList,iteration):
    alph = 0.01
    w = [random.random(),random.random(),random.random(),random.random()]
    # w = [0.1,0.1,0.1,0.1]

    w=np.matrix(w)
    print(w)
    n = 2000
    wBest = w
    notSatisfiedNumber=[]
    notSatisfiedCoefficient=[]

    for i in range(iteration):
        count =0
        notSatisfiedCoefficient = []
        notSatisfiedNumber = []
        for index in range(len(xDataList)):


            yOut = calculate(w,xDataList[index])

            yTarget = yDataList[index]

            if yOut != yTarget:
                count=count+1
                notSatisfiedNumber.append(index)
                notSatisfiedCoefficient.append(yTarget-yOut)
        if len(notSatisfiedNumber)!=0:

            w = w + np.matrix(alph * (notSatisfiedCoefficient[0])) * xDataList[notSatisfiedNumber[0]]

        print (count)
        plt.scatter(i, count, marker='o', color='r')

        if count < n:
            n=count
            wBest=w

        #print(i," : ",n)
    plt.title("Number of misclassified points against the number of iterations")
    plt.xlabel("Number of iteration")
    plt.ylabel("Number of misclassified points")
    plt.show()
    print(wBest)
    return wBest

def linearClassificationPocket2(xDataList,yDataList,iteration):
    alph = 0.01
    w = [random.random(),random.random(),random.random(),random.random()]
    # w = [0.1,0.1,0.1,0.1]

    w=np.matrix(w)
    print(w)
    n = 2000
    wBest = w

    for i in range(iteration):
        count =0

        for index in range(len(xDataList)):

            yOut = calculate(w,xDataList[index])

            yTarget = yDataList[index]

            if yOut != yTarget:
                count=count+1
                w = w + np.matrix(alph * (yTarget-yOut)) * xDataList[index]

        if count < n:
            n=count
            wBest=w

        print(i," : ",n)

    print(wBest)
    return wBest


if __name__ == '__main__':

    xDataList,yDataList = getDataFromFile("Classification.txt")
    # drawOrigList(xDataList,yDataList)                             ## draw all data point into the 3D

    ### Perceptron the first version
    # w = linearClassificationPerceptronMethod1(xDataList,yDataList)
    # drawClassList(xDataList,yDataList,w)                            ## draw a plane to classify these points


    ### Perceptron the second version
    w = linearClassificationPerceptronMethod2(xDataList, yDataList)
    drawClassList(xDataList, yDataList, w)  ## draw a plane to classify these points



    ################################################################################################################################
    # ...............................................................................................................#
    # boundary. Above is Perceptron learning algorithm. below is pocket algorithm.
    # ...............................................................................................................#
    ################################################################################################################################


    # xDataList,yDataList = getDataFromFile2("Classification.txt")
    # # drawOrigList(xDataList, yDataList)
    # w = linearClassificationPocket1(xDataList, yDataList,7000)
    # drawClassList(xDataList,yDataList,w)                            ## draw a plane to classify these points

